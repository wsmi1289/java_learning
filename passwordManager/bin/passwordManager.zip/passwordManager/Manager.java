package passwordManager;
import java.util.*;

public class Manager {

	public static void main(String[] args) {
		manage();
	}
	public static void manage() {
		System.out.println("new: New Password");
		System.out.println("find: Find Password");
		System.out.println("close: Close Password Manager");
		System.out.println("Enter Your Choice: ");
		choiceHandler();
	}
	private static void choiceHandler() {
		Scanner reader = new Scanner(System.in);
		String choice = reader.next();
		switch (choice) {
		case "new": newPassword(reader);
			break;
		case "find": getPassword(reader);
			break;
		case "close": closeManager();
			break;
		default: System.out.println("Not a valid Choice");
			manage();
			break;
		}
	}
	
	private static void newPassword(Scanner reader) {
		password pass = new password();
		System.out.println("Enter Website/Name");
		String name = reader.next();
		System.out.println("Enter Username");
		String user = reader.next();
		System.out.println("Enter Password");
		String newPass = reader.next();
		pass.setAll(newPass, name, user);
		manage();
	}
	
	private static void closeManager() {
		System.out.println("Bye!");
	}
	
	private static void getPassword(Scanner reader) {
		System.out.println("Enter Website");
		String website = reader.next();
		password finder = new password();
		finder.findPass(website);
		manage();
	}
}
