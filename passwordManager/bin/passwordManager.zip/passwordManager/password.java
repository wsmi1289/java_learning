package passwordManager;

//import java.awt.List;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.Scanner;

public class password extends Manager {

	private static ArrayList<password> passwordList = new ArrayList<password>();
	private String name;
	private String user;
	private String pass;
	
	public void setAll(String pass, String web, String user) {
		this.setPassword(pass);
		this.setName(web);
		this.setUser(user);
		storePassword(this);
	}
	public void findPass(String self) {
		for(password pass: passwordList) {
			if(pass.getName().equals(self)) {
				System.out.println("name: " + pass.getName());
				System.out.println("Username: " + pass.getUser());
				System.out.println("Password: " + pass.getPassword());
			}
		}
	}
	private void setPassword(String pass) {
		this.pass = pass;
	}
	private void setName(String website) {
		this.name = website;
//		return null;
	}
	private void setUser(String user) {
		this.user = user;
	}
	private String getPassword() {
		return pass;
	}
	private String getUser() {
		return user;
	}
	private String getName() {
		return name;
	}
	
	private static void storePassword(password self) {
		passwordList.add(self);
		System.out.println("Stored");
	}
}
